const initialState = {
    formData: []
}

const FormDataReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'formData':
            return {
                ...action.payload
            };
        default:
            return state;
    }
};

export default FormDataReducer;